پروژه اندروید SH01
این پروژه پوسته اندروید WebView است و سایت آنلاین را با همان طراحی و رنگ‌بندی نمایش می‌دهد.
آدرس سایت: https://sh01-3b17.onrender.com/
این ZIP خودش APK نیست؛ پروژه قابل ساخت است.
برای ساخت APK باید Android Studio روی کامپیوتر نصب باشد:
1) پوشه پروژه را در Android Studio باز کنید.
2) منتظر بمانید Gradle Sync کامل شود.
3) از منو Build > Build Bundle(s) / APK(s) > Build APK(s) را بزنید.
4) خروجی معمولاً در app/build/outputs/apk/debug/app-debug.apk است.
اگر آدرس سایت عوض شد، SITE_URL را در MainActivity.java تغییر دهید.
اپ فقط زمانی کار می‌کند که سایت آنلاین باشد.
