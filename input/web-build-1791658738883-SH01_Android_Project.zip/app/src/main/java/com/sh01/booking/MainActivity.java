package com.sh01.booking;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.graphics.Color;
public class MainActivity extends Activity {
 private WebView webView;
 private static final String SITE_URL = "https://sh01-3b17.onrender.com/";
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().setStatusBarColor(Color.rgb(245,248,252));
  getWindow().setNavigationBarColor(Color.rgb(245,248,252));
  getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
  webView = new WebView(this);
  webView.setBackgroundColor(Color.rgb(245,248,252));
  WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  s.setLoadsImagesAutomatically(true); s.setSupportZoom(false);
  webView.setWebViewClient(new WebViewClient() {
   @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
    String scheme=request.getUrl().getScheme(); return !("https".equals(scheme)||"http".equals(scheme));
   }
  });
  webView.setWebChromeClient(new WebChromeClient()); setContentView(webView); webView.loadUrl(SITE_URL);
 }
 @Override public void onBackPressed(){ if(webView!=null&&webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
